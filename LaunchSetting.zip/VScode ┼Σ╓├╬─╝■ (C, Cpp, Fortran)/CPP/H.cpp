#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
    printf("Hello world!");
    puts("Hello world!!");
    cout << "Hello world!!!" << endl;
    system("pause");
    return 0;
}


/*
Hello World!
*/