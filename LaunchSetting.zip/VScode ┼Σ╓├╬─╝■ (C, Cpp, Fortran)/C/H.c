#include<stdio.h>
#include<windows.h>
int main(void)
{
    printf("hello world!!");
    system("pause");
    return 0;
}